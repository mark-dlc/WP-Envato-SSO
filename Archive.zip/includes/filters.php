<?php
/**
 * Main Plugin Filters
 */

defined( 'ABSPATH' ) or die( 'No script kiddies please!' );